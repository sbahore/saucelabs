package com.app.health.Magnificent.controller;

import com.app.health.Magnificent.model.ResponseModel;
import com.app.health.Magnificent.service.HealthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {
    @Autowired
    HealthService healthService;

    @GetMapping("/api/health")

    public ResponseModel getHealthStatus() {
        return healthService.retrieveHealthAndCurrentStatus();
    }
}
