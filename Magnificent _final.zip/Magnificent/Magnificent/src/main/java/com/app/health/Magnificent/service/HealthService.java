package com.app.health.Magnificent.service;

import com.app.health.Magnificent.model.ResponseModel;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.atomic.AtomicLong;

@Service
public class HealthService {
    private static AtomicLong successCounter = new AtomicLong(0);
    private static AtomicLong failureCounter = new AtomicLong(0);
    private static volatile double percentage;
    private RestTemplate restTemplate = new RestTemplate();
    private String fooResourceUrl = "https://api.us-west-1.saucelabs.com/v1/magnificent/";

    //Schedule job to check API  and maintain its status for future
    @Scheduled(fixedRate = 5000)
    public void scheduleRunForAPIHealth() {
        try {
            ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/1", String.class);
            if (response
                    .getStatusCode()
                    .isError()) {
                failureCounter.getAndIncrement();
            } else successCounter.getAndIncrement();
        } catch (HttpStatusCodeException exception) {
            failureCounter.getAndIncrement();
        }
    }


    //Schedule job to check API  and maintain its status for future
    @Scheduled(cron = " 0 0 */1 * * ?")
    public void resetCounter() {
        successCounter.set(0);
        failureCounter.set(0);
    }

    public ResponseModel retrieveHealthAndCurrentStatus() {
            try {
                ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/1", String.class);
                Double total = (successCounter.doubleValue() + failureCounter.doubleValue());
                percentage = (successCounter.doubleValue() / total) * 100L;
                return ResponseModel
                        .builder()
                        .responseCode(response
                                .getStatusCode()
                                .value())
                        .health(percentage)
                        .message(response.getBody())
                        .build();
            } catch (HttpStatusCodeException exception) {
                Double total = (successCounter.doubleValue() + failureCounter.doubleValue());
                percentage = (successCounter.doubleValue() / total) * 100L;
                return ResponseModel
                        .builder()
                        .responseCode(exception.getRawStatusCode())
                        .message(exception.getMessage())
                        .health(percentage)
                        .build();
            }
    }

}
