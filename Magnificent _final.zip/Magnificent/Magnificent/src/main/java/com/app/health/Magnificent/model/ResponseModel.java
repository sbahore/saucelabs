package com.app.health.Magnificent.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class ResponseModel {

    private String message;
    private Integer responseCode;
    private Double health;
}
